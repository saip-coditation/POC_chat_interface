from django.apps import AppConfig

class AiDataPlatformConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'ai_data_platform'
    verbose_name = "AI Data Platform"
